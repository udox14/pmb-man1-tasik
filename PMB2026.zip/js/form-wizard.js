// js/form-wizard.js

/* ===========================================================
   1. GLOBAL VARIABLES (WAJIB DI LUAR FUNGSI)
   =========================================================== */
window.currentStep = 1;
window.totalStep = 4; // Default Reguler
const API_BASE = 'https://www.emsifa.com/api-wilayah-indonesia/api';

// Cek apakah di halaman formulir
const formElement = document.getElementById('pmbForm');
if (formElement) {
    initFormPage();
}

function initFormPage() {
    // 1. Cek Sesi
    const urlParams = new URLSearchParams(window.location.search);
    let nisnSesi = localStorage.getItem('pmb_nisn');
    let jalurSesi = localStorage.getItem('pmb_jalur');

    if (!nisnSesi) nisnSesi = urlParams.get('nisn');
    if (!jalurSesi) jalurSesi = urlParams.get('jalur');

    if (!nisnSesi || !jalurSesi) {
        alert('Akses ditolak. Silakan masukkan NISN di halaman utama.');
        window.location.href = 'index.html';
        return;
    }
    
    // Simpan ulang sesi
    localStorage.setItem('pmb_nisn', nisnSesi);
    localStorage.setItem('pmb_jalur', jalurSesi);

    // Set Hidden Input NISN
    const nisnField = document.getElementById('nisn');
    if (nisnField) nisnField.value = nisnSesi;
    
    // Setup Langkah Khusus Prestasi
    if (jalurSesi === 'PRESTASI') {
        window.totalStep = 5; 
        const stepIcon5 = document.getElementById('step-icon-5');
        if (stepIcon5) stepIcon5.style.display = 'flex';
        // Inisialisasi UI Prestasi
        setTimeout(initPrestasiUI, 500); 
    }

    // Load Data Awal
    initWilayah();      
    setupAutoSave();    
    setupBackButton();
}

/* ===========================================================
   2. API WILAYAH INDONESIA
   =========================================================== */
async function fetchWilayah(endpoint) {
    try {
        const response = await fetch(`${API_BASE}/${endpoint}.json`);
        if (!response.ok) throw new Error('API Error');
        return await response.json();
    } catch (error) {
        return [];
    }
}

async function initWilayah() {
    const select = document.getElementById('provinsi');
    if(!select) return;
    
    select.innerHTML = '<option value="">Loading...</option>';
    const provinces = await fetchWilayah('provinces');
    
    select.innerHTML = '<option value="">- Pilih Provinsi -</option>';
    provinces.forEach(p => {
        select.innerHTML += `<option value="${p.id}" data-name="${p.name}">${p.name}</option>`;
    });

    const savedProv = localStorage.getItem('draft_provinsi');
    if (savedProv) {
        select.value = savedProv;
        if (select.value) window.loadKabupaten(); 
    }
}

// DIPASANG KE WINDOW AGAR BISA DIPANGGIL HTML
window.loadKabupaten = async function() {
    const provId = document.getElementById('provinsi').value;
    const select = document.getElementById('kabupaten');
    if(!select) return;

    select.innerHTML = '<option value="">Loading...</option>'; 
    select.disabled = true;
    localStorage.setItem('draft_provinsi', provId);

    if (provId) {
        const data = await fetchWilayah(`regencies/${provId}`);
        select.innerHTML = '<option value="">- Pilih Kota/Kab -</option>';
        if (data.length > 0) {
            data.forEach(d => select.innerHTML += `<option value="${d.id}" data-name="${d.name}">${d.name}</option>`);
            select.disabled = false;
            const savedKab = localStorage.getItem('draft_kabupaten');
            if (savedKab && select.querySelector(`option[value="${savedKab}"]`)) {
                select.value = savedKab;
                window.loadKecamatan();
            }
        }
    } else {
        select.innerHTML = '<option value="">Pilih Provinsi Dulu</option>';
    }
};

window.loadKecamatan = async function() {
    const kabId = document.getElementById('kabupaten').value;
    const select = document.getElementById('kecamatan');
    if(!select) return;

    select.innerHTML = '<option value="">Loading...</option>'; 
    select.disabled = true;
    localStorage.setItem('draft_kabupaten', kabId);

    if (kabId) {
        const data = await fetchWilayah(`districts/${kabId}`);
        select.innerHTML = '<option value="">- Pilih Kecamatan -</option>';
        if (data.length > 0) {
            data.forEach(d => select.innerHTML += `<option value="${d.id}" data-name="${d.name}">${d.name}</option>`);
            select.disabled = false;
            const savedKec = localStorage.getItem('draft_kecamatan');
            if (savedKec && select.querySelector(`option[value="${savedKec}"]`)) {
                select.value = savedKec;
                window.loadDesa();
            }
        }
    } else {
        select.innerHTML = '<option value="">Pilih Kota/Kab Dulu</option>';
    }
};

window.loadDesa = async function() {
    const kecId = document.getElementById('kecamatan').value;
    const select = document.getElementById('desa');
    if(!select) return;

    select.innerHTML = '<option value="">Loading...</option>'; 
    select.disabled = true;
    localStorage.setItem('draft_kecamatan', kecId);

    if (kecId) {
        const data = await fetchWilayah(`villages/${kecId}`);
        select.innerHTML = '<option value="">- Pilih Desa/Kel -</option>';
        if (data.length > 0) {
            data.forEach(d => select.innerHTML += `<option value="${d.id}" data-name="${d.name}">${d.name}</option>`);
            select.disabled = false;
            const savedDesa = localStorage.getItem('draft_desa');
            if (savedDesa && select.querySelector(`option[value="${savedDesa}"]`)) {
                select.value = savedDesa;
            }
        }
    } else {
        select.innerHTML = '<option value="">Pilih Kecamatan Dulu</option>';
    }
};

document.addEventListener('change', function(e) {
    if (e.target && e.target.id === 'desa') {
        localStorage.setItem('draft_desa', e.target.value);
    }
});


/* ===========================================================
   3. LOGIKA WIZARD (STEPPER)
   =========================================================== */
const STEP_LABELS = {
    1: 'Data Peserta Didik',
    2: 'Data Keluarga',
    3: 'Asal Sekolah & Pesantren',
    4: 'Upload Berkas',
    5: 'Data Prestasi'
};

function showStep(step) {
    document.querySelectorAll('.form-section').forEach(el => el.classList.remove('active'));
    const section = document.getElementById(`section-${step}`);
    if (section) section.classList.add('active');

    // Update pmb-step dots
    document.querySelectorAll('.pmb-step').forEach((el, index) => {
        el.classList.remove('active', 'finished');
        if (index + 1 === step) el.classList.add('active');
        else if (index + 1 < step) el.classList.add('finished');
    });

    // Update dot icon: finished -> centang
    document.querySelectorAll('.pmb-step').forEach((el, index) => {
        const dot = el.querySelector('.pmb-step-dot');
        const icon = dot ? dot.querySelector('i') : null;
        if (!icon) return;
        const originalIcons = ['ph-user','ph-users-three','ph-graduation-cap','ph-upload-simple','ph-trophy'];
        if (index + 1 < step) {
            icon.className = 'ph ph-check-bold';
        } else {
            if (originalIcons[index]) icon.className = `ph ${originalIcons[index]}`;
        }
    });

    // Update progress bar
    const total = window.totalStep;
    const pct = Math.round((step / total) * 100);
    const fill = document.getElementById('pmb-progress-fill');
    const label = document.getElementById('pmb-step-label');
    const pctEl = document.getElementById('pmb-step-pct');
    if (fill) fill.style.width = pct + '%';
    if (label) label.innerHTML = `Langkah ${step} dari ${total} &nbsp;·&nbsp; <b>${STEP_LABELS[step] || ''}</b>`;
    if (pctEl) pctEl.textContent = pct + '%';

    const btnPrev = document.getElementById('btn-prev');
    const btnNext = document.getElementById('btn-next');
    const btnSubmit = document.getElementById('btn-submit');

    if(btnPrev) btnPrev.style.display = step === 1 ? 'none' : 'inline-flex';

    if (step === window.totalStep) {
        if(btnNext) btnNext.style.display = 'none';
        if(btnSubmit) btnSubmit.style.display = 'inline-flex';
    } else {
        if(btnNext) btnNext.style.display = 'inline-flex';
        if(btnSubmit) btnSubmit.style.display = 'none';
    }
}

// VALIDASI VISUAL
function validateSection(step) {
    const section = document.getElementById(`section-${step}`);
    if (!section) return true;

    // Validasi digit khusus per section
    if (step === 1) {
        const nikInput = document.getElementById('nik');
        if (nikInput && nikInput.value.length !== 16) {
            Swal.fire('NIK Tidak Valid', 'NIK Siswa harus tepat 16 digit.', 'warning');
            nikInput.style.borderColor = '#ef4444';
            nikInput.style.backgroundColor = '#fff5f5';
            const errorEl = document.getElementById('nik-error');
            if (errorEl) errorEl.style.display = 'block';
            return false;
        }
    }

    if (step === 2) {
        const checks = [
            { id: 'no_kk',   digits: 16, label: 'Nomor KK',  errorId: 'no_kk-error' },
            { id: 'nik_ayah', digits: 16, label: 'NIK Ayah', errorId: 'nik_ayah-error' },
            { id: 'nik_ibu',  digits: 16, label: 'NIK Ibu',  errorId: 'nik_ibu-error' },
        ];
        for (const c of checks) {
            const el = document.getElementById(c.id);
            if (el && el.value.length !== c.digits) {
                Swal.fire(`${c.label} Tidak Valid`, `${c.label} harus tepat ${c.digits} digit.`, 'warning');
                el.style.borderColor = '#ef4444';
                el.style.backgroundColor = '#fff5f5';
                const errorEl = document.getElementById(c.errorId);
                if (errorEl) errorEl.style.display = 'block';
                return false;
            }
        }
    }

    if (step === 3) {
        const npsn = document.getElementById('npsn_sekolah');
        if (npsn && npsn.value.length !== 8) {
            Swal.fire('NPSN Tidak Valid', 'NPSN harus tepat 8 digit.', 'warning');
            npsn.style.borderColor = '#ef4444';
            npsn.style.backgroundColor = '#fff5f5';
            const errorEl = document.getElementById('npsn-error');
            if (errorEl) errorEl.style.display = 'block';
            return false;
        }
    }

    const inputs = section.querySelectorAll('input[required]:not(:disabled), select[required]:not(:disabled), textarea[required]:not(:disabled)');
    let isValid = true;

    inputs.forEach(input => {
        let isEmpty = !input.value;
        if (input.type === 'file') isEmpty = input.files.length === 0;

        const errorBorder = '#ef4444';
        const errorBg = '#fff5f5';
        const normalBorder = '#cbd5e1';
        const normalBg = '#ffffff';
        const fileBg = '#f0fdfa';

        if (isEmpty) {
            isValid = false;
            // STYLE ERROR
            if (input.type === 'file' && input.parentElement.classList.contains('upload-card-item')) {
                input.parentElement.style.borderColor = errorBorder;
                input.parentElement.style.backgroundColor = normalBg;
                const statusSpan = input.parentElement.querySelector('.upload-status-text');
                if (statusSpan) { 
                    statusSpan.innerText = "Wajib diisi!"; 
                    statusSpan.style.color = errorBorder; 
                    statusSpan.style.fontWeight = 'bold';
                }
            } else {
                input.style.borderColor = errorBorder;
                input.style.backgroundColor = errorBg;
            }
        } else {
            // STYLE NORMAL
            if (input.type === 'file' && input.parentElement.classList.contains('upload-card-item')) {
                if(input.parentElement.style.borderColor === 'rgb(239, 68, 68)' || input.parentElement.style.borderColor === '#ef4444') {
                     input.parentElement.style.borderColor = 'var(--primary)'; 
                     input.parentElement.style.backgroundColor = fileBg; 
                }
            } else {
                input.style.borderColor = normalBorder;
                input.style.backgroundColor = normalBg;
            }
        }
    });

    if (!isValid) {
        Swal.fire('Data Belum Lengkap', 'Mohon lengkapi kolom yang berwarna merah.', 'warning');
    }
    return isValid;
}

// FUNGSI NEXT DIPASANG KE WINDOW
window.nextStep = function() {
    if (validateSection(window.currentStep)) {
        window.currentStep++;
        showStep(window.currentStep);
        window.scrollTo(0,0);
    }
};

window.prevStep = function() {
    window.currentStep--;
    showStep(window.currentStep);
    window.scrollTo(0,0);
};


/* ===========================================================
   4. LOGIKA PRESTASI
   =========================================================== */
function initPrestasiUI() {
    const container = document.getElementById('container-prestasi');
    if (!container) return;
    
    const oldBtn = document.querySelector('button[onclick="tambahPrestasi()"]');
    if(oldBtn) oldBtn.style.display = 'none';

    // Inject CSS Internal (Hanya jika belum ada)
    if (!document.getElementById('prestasi-style')) {
        const style = document.createElement('style');
        style.id = 'prestasi-style';
        style.innerHTML = `
            .pres-category-box { background: white; border: 1px solid #e2e8f0; border-radius: 12px; padding: 20px; margin-bottom: 25px; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.02); }
            .pres-cat-header { font-weight: 800; color: var(--primary); font-size: 1.1rem; margin-bottom: 15px; border-bottom: 2px solid #f1f5f9; padding-bottom: 10px; display: flex; justify-content: space-between; align-items: center; }
            .pres-row { display: grid; grid-template-columns: 1fr; gap: 10px; background: #f8fafc; padding: 15px; border-radius: 8px; margin-bottom: 10px; position: relative; border: 1px dashed #cbd5e1; }
            .pres-row-tahfidz { display: grid; grid-template-columns: 1fr; gap: 10px; background: #f0fdfa; padding: 15px; border-radius: 8px; margin-bottom: 10px; border: 1px solid #ccfbf1; }
            @media(min-width: 900px) {
                .pres-row { grid-template-columns: 2fr 2fr 1.2fr 0.8fr 40px; align-items: end; }
                .pres-row-tahfidz { grid-template-columns: 1.5fr 1fr 1fr; align-items: end; }
            }
            .pres-label { font-size: 0.75rem; font-weight: 700; color: #64748b; margin-bottom: 4px; display: block; text-transform: uppercase; }
            .btn-add-pres { background: #f1f5f9; color: var(--primary); border: 1px dashed var(--primary); width: 100%; padding: 10px; border-radius: 8px; font-weight: 600; cursor: pointer; transition: 0.2s; }
            .btn-add-pres:hover { background: #e0f2f1; }
            .btn-del-pres { color: #ef4444; background: white; border: 1px solid #fecaca; width: 36px; height: 36px; border-radius: 6px; cursor: pointer; display: flex; align-items: center; justify-content: center; }
            .btn-del-pres:hover { background: #fef2f2; }
        `;
        document.head.appendChild(style);
    }

    // INJECT HTML
    container.innerHTML = `
        <div class="pres-category-box">
            <div class="pres-cat-header"><span>📚 Prestasi Akademik</span><small style="font-weight:400; color:#64748b;">(OSN, OMI, Debat, dll)</small></div>
            <div id="list-akademik"></div>
            <button class="btn-add-pres" onclick="addPrestasiRow('akademik')">+ Tambah (Maks 3)</button>
        </div>
        <div class="pres-category-box">
            <div class="pres-cat-header"><span>⚽ Prestasi Non-Akademik</span><small style="font-weight:400; color:#64748b;">(Olah Raga, Seni, LKBB)</small></div>
            <div id="list-nonakademik"></div>
            <button class="btn-add-pres" onclick="addPrestasiRow('nonakademik')">+ Tambah (Maks 3)</button>
        </div>
        <div class="pres-category-box">
            <div class="pres-cat-header"><span>🕌 Prestasi Keagamaan</span><small style="font-weight:400; color:#64748b;">(MQK, MTQ, dll)</small></div>
            <div id="list-keagamaan"></div>
            <button class="btn-add-pres" onclick="addPrestasiRow('keagamaan')">+ Tambah (Maks 3)</button>
        </div>
        <div class="pres-category-box" style="border-color: #10b981;">
            <div class="pres-cat-header" style="color: #047857;"><span>📖 Tahfidz Al-Qur'an</span><small style="font-weight:400; color:#64748b;">(Min. 10 Juz)</small></div>
            <div id="list-tahfidz">
                <div class="pres-row-tahfidz">
                    <div><label class="pres-label">Jumlah Hafalan (Juz)</label><input type="number" class="input-modern-form tahfidz-juz" placeholder="Min. 10"></div>
                    <div><label class="pres-label">Tahun Selesai</label><input type="number" class="input-modern-form tahfidz-tahun" placeholder="YYYY"></div>
                    <div><label class="pres-label">Status Mutqin</label><select class="input-modern-form tahfidz-mutqin"><option value="">- Pilih -</option><option value="Mutqin">Mutqin</option><option value="Belum Mutqin">Belum Mutqin</option></select></div>
                </div>
            </div>
        </div>
        
        <!-- UPLOAD SERTIFIKAT: 2MB -->
        <div class="upload-grid-modern" style="margin-top: 30px;">
            <div class="upload-card-item" style="border-color: var(--accent); background: #fffbeb; grid-column: 1 / -1;">
                <input type="file" id="file_sertifikat" accept=".pdf" onchange="validateSimpleUpload(this, 2048)">
                <div class="upload-icon-box" style="color: #d97706;"><i class="ph ph-trophy"></i></div>
                <span class="upload-label-text" style="color: #92400e;">Upload Sertifikat Prestasi (Gabung 1 PDF) *</span>
                <span class="upload-status-text" id="lbl-file_sertifikat">Max 2MB (PDF Only)</span>
            </div>
        </div>
    `;
    
    // Sembunyikan elemen upload statis jika ada (untuk mencegah duplikat)
    const oldFile = document.querySelector('#section-5 > div[style*="background"]');
    if(oldFile) oldFile.style.display = 'none';
}

window.addPrestasiRow = function(category) {
    const listId = `list-${category}`;
    const container = document.getElementById(listId);
    if (container.children.length >= 3) {
        Swal.fire('Batas Maksimal', 'Maksimal 3 prestasi untuk kategori ini.', 'warning');
        return;
    }
    const row = document.createElement('div');
    row.className = 'pres-row';
    row.dataset.cat = category; 
    row.innerHTML = `
        <div><label class="pres-label">Nama Lomba</label><input type="text" class="input-modern-form pres-nama" placeholder="Nama Prestasi" style="text-transform:uppercase;"></div>
        <div><label class="pres-label">Penyelenggara</label><input type="text" class="input-modern-form pres-oleh" placeholder="Penyelenggara" style="text-transform:uppercase;"></div>
        <div><label class="pres-label">Tingkat</label><select class="input-modern-form pres-tingkat"><option value="Provinsi">Provinsi</option><option value="Nasional">Nasional</option><option value="Internasional">Internasional</option></select></div>
        <div><label class="pres-label">Tahun</label><input type="number" class="input-modern-form pres-tahun" placeholder="YYYY"></div>
        <button class="btn-del-pres" onclick="this.parentElement.remove()" title="Hapus"><i class="ph ph-trash"></i></button>
    `;
    container.appendChild(row);
};

// --- UTILS: COMPRESS ---
function compressImage(file, quality) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = event => {
            const img = new Image();
            img.src = event.target.result;
            img.onload = () => {
                const canvas = document.createElement('canvas');
                let width = img.width;
                let height = img.height;
                const MAX_WIDTH = 2000;
                if (width > MAX_WIDTH) { height *= MAX_WIDTH / width; width = MAX_WIDTH; }
                canvas.width = width; canvas.height = height;
                const ctx = canvas.getContext('2d');
                ctx.drawImage(img, 0, 0, width, height);
                canvas.toBlob(blob => { blob.name = file.name.replace(/\.[^/.]+$/, "") + ".jpg"; resolve(blob); }, 'image/jpeg', quality);
            };
            img.onerror = error => reject(error);
        };
        reader.onerror = error => reject(error);
    });
}

// --- SYSTEM: AUTO SAVE TEXT ONLY ---
function setupAutoSave() {
    const inputs = document.querySelectorAll('#pmbForm input:not([type="file"]), #pmbForm select, #pmbForm textarea');
    inputs.forEach(input => {
        if (input.id === 'nisn' || input.id === 'provinsi' || input.id === 'kabupaten' || input.id === 'kecamatan' || input.id === 'desa') return;
        const savedValue = localStorage.getItem('draft_' + input.id);
        if (savedValue) input.value = savedValue;
        input.addEventListener('input', function() { localStorage.setItem('draft_' + this.id, this.value); });
        input.addEventListener('change', function() { localStorage.setItem('draft_' + this.id, this.value); });
    });
}

function setupBackButton() {
    const btnBack = document.querySelector('header .nav-actions .btn-secondary');
    if(btnBack) {
        btnBack.addEventListener('click', (e) => {
            e.preventDefault();
            Swal.fire({
                title: 'Batalkan Pendaftaran?',
                text: "Data yang sudah Anda ketik akan DIHAPUS. Yakin ingin keluar?",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Ya, Keluar & Hapus Data',
                cancelButtonText: 'Lanjut Mengisi',
                confirmButtonColor: '#d33',
            }).then((result) => {
                if (result.isConfirmed) {
                    clearDraftData();
                    localStorage.removeItem('pmb_jalur');
                    localStorage.removeItem('pmb_nisn');
                    window.location.href = 'index.html';
                }
            });
        });
    }
}

function clearDraftData() {
    const inputs = document.querySelectorAll('#pmbForm input, #pmbForm select, #pmbForm textarea');
    inputs.forEach(input => { localStorage.removeItem('draft_' + input.id); });
    localStorage.removeItem('draft_provinsi');
    localStorage.removeItem('draft_kabupaten');
    localStorage.removeItem('draft_kecamatan');
    localStorage.removeItem('draft_desa');
}

// --- SUBMIT FORM ---
window.submitForm = async function() {
    if (!validateSection(window.currentStep)) return;
    const jalur = localStorage.getItem('pmb_jalur');

    if (jalur === 'PRESTASI') {
        const certFile = document.getElementById('file_sertifikat');
        if (!certFile || certFile.files.length === 0) {
            Swal.fire({icon: 'warning', title: 'Berkas Kurang', text: 'Wajib upload sertifikat prestasi.'});
            if(certFile) { certFile.parentElement.style.borderColor = '#ef4444'; certFile.parentElement.style.backgroundColor = '#fff5f5'; }
            return;
        }
        const rows = document.querySelectorAll('.pres-row');
        const tahfidzJuz = document.querySelector('.tahfidz-juz');
        const tahfidzVal = tahfidzJuz ? tahfidzJuz.value : '';

        // Cek apakah ada minimal 1 baris prestasi yang namanya terisi
        const hasFilledPrestasi = Array.from(rows).some(row => row.querySelector('.pres-nama')?.value.trim() !== '');

        // Cek tahfidz
        const isTahfidzFilled = tahfidzVal !== '' && parseInt(tahfidzVal) >= 10;
        const isTahfidzBelowMin = tahfidzVal !== '' && parseInt(tahfidzVal) < 10;

        if (isTahfidzBelowMin) {
            Swal.fire({icon: 'warning', title: 'Tahfidz Tidak Memenuhi Syarat', text: 'Hafalan Tahfidz minimal 10 Juz untuk dapat didaftarkan.'});
            tahfidzJuz.style.borderColor = '#ef4444';
            tahfidzJuz.style.backgroundColor = '#fff5f5';
            return;
        }

        if (!hasFilledPrestasi && !isTahfidzFilled) {
            Swal.fire({icon: 'warning', title: 'Data Prestasi Kosong', text: 'Wajib mengisi minimal 1 prestasi (Akademik/Non-Akademik/Keagamaan) atau Tahfidz minimal 10 Juz.'});
            return;
        }
    }

    const confirm = await Swal.fire({
        title: 'Kirim Pendaftaran?',
        text: "Pastikan data benar. Data tidak bisa diubah setelah dikirim.",
        icon: 'question',
        showCancelButton: true,
        confirmButtonText: 'Ya, Kirim!',
        cancelButtonText: 'Cek Lagi'
    });

    if (!confirm.isConfirmed) return;

    Swal.fire({
        title: 'Sedang Mengirim...',
        text: 'Mohon tunggu, sedang mengupload berkas...',
        allowOutsideClick: false,
        didOpen: () => Swal.showLoading()
    });

    try {
        const timestamp = Date.now();
        const nisn = document.getElementById('nisn').value;
        const nama = document.getElementById('nama_lengkap').value.replace(/[^a-zA-Z0-9]/g, '_');
        const folderName = `${nisn}_${nama}`;

        // Batas upload semua berkas: 2MB — upload ke R2 via /api/upload
        async function uploadFile(fileInputId, docName, maxKB, autoCompress = false) {
            const fileInput = document.getElementById(fileInputId);
            if (fileInput && fileInput.files.length > 0) {
                let file = fileInput.files[0];
                if (autoCompress && file.type.startsWith('image/')) {
                    try {
                        const compressedBlob = await compressImage(file, 0.95);
                        if (compressedBlob.size < file.size) file = compressedBlob;
                    } catch (e) { console.warn("Compress fail", e); }
                }
                const fileSizeKB = file.size / 1024;
                if (fileSizeKB > maxKB) throw new Error(`File ${docName} terlalu besar. Max ${maxKB >= 1024 ? (maxKB/1024) + ' MB' : maxKB + ' KB'}.`);
                return await apiUpload(file, folderName, docName);
            }
            return null;
        }

        // Semua berkas batas 2048 KB (2MB)
        const [fotoUrl, kkUrl, aktaUrl, skbUrl, ktpOrtuUrl, raporUrl, sertifUrl] = await Promise.all([
            uploadFile('file_foto', 'FOTO', 2048, true),
            uploadFile('file_kk', 'KK', 2048),
            uploadFile('file_akta', 'AKTA', 2048),
            uploadFile('file_skb', 'SKB', 2048),
            uploadFile('file_ktp_ortu', 'KTP_ORTU', 2048),
            uploadFile('file_rapor', 'RAPOR', 2048),
            (jalur === 'PRESTASI') ? uploadFile('file_sertifikat', 'SERTIFIKAT', 2048) : Promise.resolve(null)
        ]);

        const getSelectText = (id) => { const el = document.getElementById(id); return el.options[el.selectedIndex]?.text || ''; };

        const formData = {
            jalur: jalur,
            nisn: nisn,
            nik: document.getElementById('nik').value,
            nama_lengkap: document.getElementById('nama_lengkap').value.toUpperCase(),
            jenis_kelamin: document.getElementById('jenis_kelamin').value,
            tempat_lahir: document.getElementById('tempat_lahir').value.toUpperCase(),
            tanggal_lahir: document.getElementById('tanggal_lahir').value,
            ukuran_baju: document.getElementById('ukuran_baju').value,
            agama: 'Islam',
            jumlah_saudara: document.getElementById('jumlah_saudara').value,
            anak_ke: document.getElementById('anak_ke').value,
            status_anak: document.getElementById('status_anak').value,
            
            provinsi: getSelectText('provinsi'),
            kabupaten_kota: getSelectText('kabupaten'),
            kecamatan: getSelectText('kecamatan'),
            desa_kelurahan: getSelectText('desa'),
            rt: document.getElementById('rt').value,
            rw: document.getElementById('rw').value,
            alamat_lengkap: document.getElementById('alamat_lengkap').value.toUpperCase(),
            kode_pos: document.getElementById('kode_pos').value,
            
            no_kk: document.getElementById('no_kk').value,
            nama_ayah: document.getElementById('nama_ayah').value.toUpperCase(),
            nik_ayah: document.getElementById('nik_ayah').value,
            pendidikan_ayah: document.getElementById('pendidikan_ayah').value,
            pekerjaan_ayah: document.getElementById('pekerjaan_ayah').value.toUpperCase(),
            penghasilan_ayah: document.getElementById('penghasilan_ayah').value,
            
            nama_ibu: document.getElementById('nama_ibu').value.toUpperCase(),
            nik_ibu: document.getElementById('nik_ibu').value,
            pendidikan_ibu: document.getElementById('pendidikan_ibu').value,
            pekerjaan_ibu: document.getElementById('pekerjaan_ibu').value.toUpperCase(),
            penghasilan_ibu: document.getElementById('penghasilan_ibu').value,
            no_telepon_ortu: document.getElementById('no_telepon_ortu').value,

            asal_sekolah: document.getElementById('asal_sekolah').value.toUpperCase(),
            npsn_sekolah: document.getElementById('npsn_sekolah').value,
            status_sekolah: document.getElementById('status_sekolah').value,
            alamat_sekolah: document.getElementById('alamat_sekolah').value.toUpperCase(),
            pilihan_pesantren: document.getElementById('pilihan_pesantren').value,

            foto_url: fotoUrl,
            scan_kk_url: kkUrl,
            scan_akta_url: aktaUrl,
            scan_kelakuan_baik_url: skbUrl,
            scan_ktp_ortu_url: ktpOrtuUrl,
            scan_rapor_url: raporUrl,
            scan_sertifikat_prestasi_url: sertifUrl
        };

        const pendaftarData = await apiPost('pendaftar', formData);
        if (pendaftarData.error) throw new Error(pendaftarData.error);

        if (jalur === 'PRESTASI') {
            const pendaftarId = pendaftarData.id;
            const prestasiList = [];

            const rows = document.querySelectorAll('.pres-row');
            rows.forEach(row => {
                const nama = row.querySelector('.pres-nama').value;
                if (nama) {
                    let kat = 'Umum';
                    if (row.dataset.cat === 'akademik') kat = 'Akademik';
                    if (row.dataset.cat === 'nonakademik') kat = 'Non-Akademik';
                    if (row.dataset.cat === 'keagamaan') kat = 'Keagamaan';

                    prestasiList.push({
                        pendaftar_id: pendaftarId,
                        nama_lomba: nama.toUpperCase(),
                        penyelenggara: row.querySelector('.pres-oleh').value.toUpperCase(),
                        tingkat: row.querySelector('.pres-tingkat').value,
                        tahun_perolehan: row.querySelector('.pres-tahun').value,
                        kategori: kat
                    });
                }
            });

            const juz = document.querySelector('.tahfidz-juz').value;
            if (juz && parseInt(juz) >= 10) {
                prestasiList.push({
                    pendaftar_id: pendaftarId,
                    kategori: 'Tahfidz',
                    nama_lomba: `Hafalan ${juz} Juz`,
                    penyelenggara: '-',
                    tingkat: document.querySelector('.tahfidz-mutqin').value || '-',
                    tahun_perolehan: document.querySelector('.tahfidz-tahun').value || '-'
                });
            }

            if (prestasiList.length > 0) {
                await apiPost('prestasi', prestasiList);
            }
        }

        Swal.fire({
            icon: 'success',
            title: 'Pendaftaran Berhasil!',
            text: `Nomor Pendaftaran Anda: ${pendaftarData.no_pendaftaran}`,
            allowOutsideClick: false
        }).then(() => {
            clearDraftData();
            localStorage.removeItem('pmb_jalur');
            localStorage.removeItem('pmb_nisn');
            localStorage.setItem('resume_data', JSON.stringify(pendaftarData));
            window.location.href = 'resume.html';
        });

    } catch (err) {
        console.error(err);
        Swal.fire('Gagal Mengirim', 'Terjadi kesalahan: ' + err.message, 'error');
    }
}